import matplotlib.pyplot as plt

file1 = open('results.txt', 'r')
count = 0

results = []
cores = [1,2,3,4,5,6,7,8,9,10]
while True:
    count += 1
    line = file1.readline()
    if not line:
        break
    results.append(line.rstrip('\n'))
    print("Line{}: {}".format(count, line.strip()))
  
file1.close()

results = list(map(float,results))
print(results)
plt.figure(1)
plt.plot(cores,results)
plt.title("Execution Time against the Number of Cores Used")
plt.xlabel('Number of Cores Used')
plt.ylabel('Execution Time (s)')
plt.savefig('timesMatrix.png')

speedup = [0,0,0,0,0,0,0,0,0,0]
for i in range(10):
  speedup[i] = results[0]/results[i]
plt.figure(2)
plt.plot(cores, speedup)
plt.title("Speedup against the Number of Cores Used")
plt.xlabel('Number of Cores Used')
plt.ylabel('Speedup')
plt.savefig('speedupMatrix.png')