#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <omp.h>
#include <math.h>
#include <fstream>

using namespace std;
double matrixA[2000][2000];
double matrixB[2000][2000];
double transposeB[2000][2000];

double matrixC[2000][2000];

void populate_matrix(int n);
double parallel_for_multiplication(int n, int threads);

int main() {
	int n = 2000;
	double xy[10];
	populate_matrix(n);
	for (int i = 1; i < 11; i++) {
		double time = 0;
		time = parallel_for_multiplication(n, i);

		printf("Time taken for a %d x %d matrix over %d cores is %f s\n", n, n, i, time);
		xy[i-1] = time;
	}
	ofstream myfile("results.txt");
	if (myfile.is_open())
	{
		for (int i = 0; i < 10; i++) {
			myfile << xy[i] << "\n";
		}
		myfile.close();
	}
	return 0;
}

void populate_matrix(int n) {

	//different seed for each experiment
	srand(time(NULL));

	//populate matrices
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			matrixA[i][j] = rand();
			matrixB[i][j] = rand();
		}
	}
}
double parallel_for_multiplication(int n, int threads) {

	double startTime = omp_get_wtime();
#pragma omp parallel for shared(matrixA,  matrixB, matrixC) schedule(static) num_threads(threads)
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			matrixC[i][j] = 0;
			for (int k = 0; k < n; k++) {
#pragma omp atomic
				matrixC[i][j] = matrixC[i][j] + matrixA[i][k] * matrixB[k][j];
			}
		}
	}
	double endTime = omp_get_wtime();
	return endTime - startTime;

}
//g++ - fopenmp MatrixMultiplication.cpp - o anyname.cpp
// ./anyname.cpp
//python3 